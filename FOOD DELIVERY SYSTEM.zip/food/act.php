<?php
$servername="localhost";
$username="root";
$password="";
$db_name="food";
		
		$db = new mysqli($servername,$username,$password,$db_name);
		if($db->connect_error){
			die('connection failed:');
		}
        $insertion=mysqli_query($db,"insert into reg (name,email,address,gender,moblieno)values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[t4]','$_POST[t5]')");
		if($insertion){
	     echo("Registration successful");
        exit();
			}
?>
